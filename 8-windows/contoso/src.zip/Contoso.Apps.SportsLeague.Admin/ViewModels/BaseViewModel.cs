﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Contoso.Apps.SportsLeague.Admin.ViewModels
{
    public class BaseViewModel
    {
        public string DisplayName { get; set; }
    }
}